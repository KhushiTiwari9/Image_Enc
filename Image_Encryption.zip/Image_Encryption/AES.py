# Image Encryption using AES
# Developed by: Khushi Tiwari
# Date: April 2025

import base64
from Crypto import Random
from Crypto.Cipher import AES
import hashlib
import os

block_size = 16

def sha256(key):
    sha = hashlib.sha256()
    sha.update(key.encode('utf-8'))
    return sha.digest()

def pad(data):
    padding_length = block_size - (len(data) % block_size)
    padding = bytes([padding_length]) * padding_length
    return data + padding

def unpad(data):
    padding_length = data[-1]
    return data[:-padding_length]

def encrypt(data, key):
    data = pad(data)
    iv = Random.new().read(block_size)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(data)
    return base64.b64encode(iv + encrypted)

def decrypt(data, key):
    data = base64.b64decode(data)
    iv = data[:block_size]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(data[block_size:])
    return unpad(decrypted)

# Take file and key input
file = input('Enter the name of the file: ')

# Check if file exists
if not os.path.exists(file):
    print(f"File '{file}' not found in the current folder: {os.getcwd()}")
    exit()

key_input = input('Enter a key: ')
key = sha256(key_input)

# Read the image and convert to base64
with open(file, 'rb') as f:
    base64_data = base64.b64encode(f.read())

# Encrypt the image data
encrypted_data = encrypt(base64_data, key)
with open('encrypted_' + file, 'wb') as f:
    f.write(encrypted_data)
print("Encryption completed Successfully by Khushi Tiwari.")

# Decrypt the image data
decrypted_data = decrypt(encrypted_data, key)
with open('decrypted_' + file, 'wb') as f:
    f.write(base64.b64decode(decrypted_data))
print("Decryption completed Successfully by Khushi Tiwari.")
# AES_Image_Encryption

This is an *image encryption* script developed as part of my academic learning.  
It is based on the *AES (Advanced Encryption Standard)* algorithm.

I created this project after reading a research paper on image encryption using AES and visual cryptography.  
You can read the paper here:  
[Research Paper – AES & Visual Cryptography](https://www.researchgate.net/profile/Agilandeeswari-Loganathan/publication/315365473_A_novel_image_encryption_algorithm_using_AES_and_visual_cryptography/links/5d80d373458515fca16e45d7/A-novel-image-encryption-algorithm-using-AES-and-visual-cryptography.pdf)

## Developed By:
*Khushi Tiwari*  
April 2025

## Features
- Encrypts image files using AES
- Decrypts encrypted files back to original
- Simple command-line based interaction

## Requirements
- Python 3.x
- base64 (Python standard library)

## Usage
1. Run the AES.py file.
2. Provide the image file name when prompted.
3. Encrypted and decrypted files will be generated.

---

> This project is developed purely for educational purposes.